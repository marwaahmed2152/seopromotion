import { BookOpen, Laptop, Lightbulb, Rocket } from 'lucide-react';

const lessons = [
  {
    id: 1,
    icon: BookOpen,
    title: 'Introduction to Programming',
    description: 'Learn the fundamentals of coding with visual programming languages and interactive exercises.',
    level: 'Beginner',
  },
  {
    id: 2,
    icon: Laptop,
    title: 'Web Development Basics',
    description: 'Build your first website using HTML, CSS, and JavaScript in our hands-on projects.',
    level: 'Beginner',
  },
  {
    id: 3,
    icon: Lightbulb,
    title: 'Problem Solving & Logic',
    description: 'Develop critical thinking skills through fun coding challenges and puzzles.',
    level: 'All Levels',
  },
  {
    id: 4,
    icon: Rocket,
    title: 'Game Development',
    description: 'Create your own games and animations while learning programming concepts.',
    level: 'Intermediate',
  },
];

export function LessonsSection() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Coding Lessons
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our carefully designed curriculum to start your coding journey
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {lessons.map((lesson) => {
            const Icon = lesson.icon;
            return (
              <div
                key={lesson.id}
                className="bg-white border-2 border-blue-100 rounded-lg p-6 hover:border-blue-400 hover:shadow-lg transition-all duration-300"
              >
                <div className="bg-blue-100 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="w-7 h-7 text-blue-600" />
                </div>
                <div className="mb-3">
                  <span className="inline-block bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                    {lesson.level}
                  </span>
                </div>
                <h3 className="font-bold text-lg text-gray-900 mb-2">
                  {lesson.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {lesson.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
