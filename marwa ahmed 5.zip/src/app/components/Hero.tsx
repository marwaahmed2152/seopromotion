import { Code2 } from 'lucide-react';

export function Hero() {
  return (
    <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-white/10 backdrop-blur-sm p-4 rounded-full">
            <Code2 className="w-16 h-16" />
          </div>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Welcome to CodeCraft Tutoring
        </h1>
        <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
          We help kids and beginners learn how to code in a fun and easy way.
        </p>
      </div>
    </section>
  );
}
