import { Hero } from './components/Hero';
import { LessonsSection } from './components/LessonsSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <LessonsSection />
      <Footer />
    </div>
  );
}
